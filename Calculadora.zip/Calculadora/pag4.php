<?php 
$numero = isset ($_GET['multi']) ? $_GET['multi'] : false;
$numero2 = isset ($_GET['multi2']) ? $_GET['multi2'] : false;
$reM= $numero * $numero2;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado</title>
</head>
<body>
<form method="get" action="pag1.php">
<p>O resultudo da multiplicação: <?php print_r ("$reM"); ?></p><br>
<input type="submit" value="voltar">
</form>
</body>
</html>