<p>Fazendo a multiplicação dos números<p>

    <label>Entre com um valores<br></label>
    <input type="number" name="multi" min="0"> <br>

    <label>Entre com um valores<br></label>
    <input type="number" name="multi2" min="0"> <br>

    <p>Fazendo a soma dos números<p>

    <label>Entre com um valores<br></label>
    <input type="number" name="soma" min="0"> <br>

    <label>Entre com um valores<br></label>
    <input type="number" name="soma2" min="0"> <br>

    <p>Fazendo a subtração dos números<p>

<label>Entre com um valores<br></label>
<input type="number" name="sub" min="0"> <br>

<label>Entre com um valores<br></label>
<input type="number" name="sub2" min="0"> <br>

<p>Fazendo a divisão dos números<p>

<label>Entre com um valores<br></label>
<input type="number" name="div" min="0"> <br>

<label>Entre com um valores<br></label>
<input type="number" name="div2" min="0"> <br>
*/