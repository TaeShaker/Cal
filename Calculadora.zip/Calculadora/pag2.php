<?php
/*
$numero = isset ($_GET['multi']) ? $_GET['multi'] : false;
$numero2 = isset ($_GET['multi2']) ? $_GET['multi2'] : false;
$reM= $numero * $numero2;
//print_r ("O resultado é $reM");
*/

$numero3 = isset ($_GET['soma']) ? $_GET['soma'] : false;
$numero4 = isset ($_GET['soma2']) ? $_GET['soma'] : false;
$reS = $numero3 + $numero4;
//

/*
$numero5= isset ($_GET['sub']) ? $_GET['sub'] : false;
$numero6 = isset ($_GET['sub2']) ? $_GET['sub2'] : false;
$reSS = $numero5 - $numero6;
//
/*
$numero7 = isset ($_GET['div']) ? $_GET['div'] : false;
$numero8 = isset ($_GET['div2']) ? $_GET['div2'] : false;
$reD = $numero7 / $numero8;
*/

//$mult = 2;
//$resu = $numero * $mult;

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado</title>
</head>
<body>
<form method="get" action="pag1.php"><br>
<p>O resultudo da subtração: <?php print_r ("$reS"); ?></p>
    <input type="submit" value="voltar" />
</form>
</body>
</html>

