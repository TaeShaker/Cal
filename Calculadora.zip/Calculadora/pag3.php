<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiplicação</title>
</head>
<body>
    
    <form action="pag4.php" method="get">
    <p>Fazendo a multiplicação dos números<p>

<label>Entre com um valores<br></label>
<input type="number" name="multi" min="0"> <br>

<label>Entre com um valores<br></label>
<input type="number" name="multi2" min="0"> <br>
<input type="submit" value="calcular">
</form>
</body>
</html>