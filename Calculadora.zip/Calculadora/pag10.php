<?php
$numero7 = isset ($_GET['div']) ? $_GET['div'] : false;
$numero8 = isset ($_GET['div2']) ? $_GET['div2'] : false;
$reD = $numero7 / $numero8;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado</title>
</head>
<body>
<form method="get" action="pag1.php"><br>
<p>O resultudo da divisão: <?php print_r ("$reD"); ?></p>
    <input type="submit" value="voltar" />
</form>
</body>
</html>