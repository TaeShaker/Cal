
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora</title>
</head>
<body>
    <h4>Calculadora online</h4>
<p>Escolha uma das funções abaixo:</p>

<form method="get" action="pag3.php">
    <input type="submit" value="multiplicação"/>
</form>

<form method="get" action="pag5.php">
    <input type="submit" value="soma"/>
</form>
    <form method="get" action="pag7.php">
    <input type="submit" value="subtração"/>
</form>
    <form method="get" action="pag9.php">
    <input type="submit" value="divisão"/>
</form>


</body>
</html>
