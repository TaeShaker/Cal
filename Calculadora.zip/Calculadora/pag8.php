<?php
$numero5= isset ($_GET['sub']) ? $_GET['sub'] : false;
$numero6 = isset ($_GET['sub2']) ? $_GET['sub2'] : false;
$reSS = $numero5 - $numero6;
?>

<html>
    <head></head>
    <body>
        <form action="pag1.php" method="get">
    <p>O resultudo da subtração: <?php print_r ("$reSS"); ?></p>
    <input type="submit" value="voltar" />
</form>
</body>
</html>