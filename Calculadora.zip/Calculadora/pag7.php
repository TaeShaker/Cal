<html>
    <head>
        <title>Subtração</title>
    </head>
<body>
    <form method="get" action="pag8.php">
    <p>Fazendo a subtração dos números</p>

        <label>Entre com um valores<br></label>
        <input type="number" name="sub" min="0"> <br>
        
        <label>Entre com um valores<br></label>
        <input type="number" name="sub2" min="0"> <br>
        <input type="submit" value="subtrair">
        
    </form>
    </body>
    </html