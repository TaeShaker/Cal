<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soma</title>
</head>
<body>
<form action="pag2.php" method="get">
<p>Fazendo a soma dos números<p>

<label>Entre com um valores<br></label>
<input type="number" name="soma" min="0"> <br>

<label>Entre com um valores<br></label>
<input type="number" name="soma2" min="0"> <br>
<input type="submit" value="somar">
</form>